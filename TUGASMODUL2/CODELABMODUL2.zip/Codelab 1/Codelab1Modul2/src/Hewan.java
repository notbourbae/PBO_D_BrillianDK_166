public class Hewan {
    String nama, jenis, suara;

    void tampilkaninfo() {
        System.out.println("Nama: " + nama);
        System.out.println("Jenis: " + jenis);
        System.out.println("Suara: " + suara);
    }
}